class TImages {
  TImages._();

  static const String logo = "assets/images/logo.png"; // Placeholder
  // Add other images here as we discover them
}
